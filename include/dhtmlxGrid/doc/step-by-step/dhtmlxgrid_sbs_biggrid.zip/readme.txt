To see sample in action unpack content of this archive into doc folder of dhtmlxGrid directory. 
Thus relative paths to codebase directory remain actual.


(c) DHTMLX LTD.