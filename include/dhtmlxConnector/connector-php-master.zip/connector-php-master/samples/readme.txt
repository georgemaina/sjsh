Expected php.ini settings
	magic_quotes off
	error_level E_ALL & ~E_NOTICE
		
	
Before running samples, make sure that db connection settings in config.php are set properly and database was filled from dump.sql file

(c) dhtmlx ltd.