<?php
$root_path='../../../';
$top_dir='modules/accounting/';
# Root path used in templates
$TP_root_path='../../';
?>
