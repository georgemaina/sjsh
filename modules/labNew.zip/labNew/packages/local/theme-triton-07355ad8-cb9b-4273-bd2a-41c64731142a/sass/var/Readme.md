# theme-triton-07355ad8-cb9b-4273-bd2a-41c64731142a/sass/var

This folder contains variable declaration files named by their component class.
