<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$rptType=$_REQUEST['rptType'];

if($rptType=='diagnosis'){
    
}

?>
