<?php
/**
 * Created by PhpStorm.
 * User: george
 * Date: 9/9/2015
 * Time: 1:00 PM
 */
?>
<!DOCTYPE html>

<!-- Auto Generated with Sencha Architect -->
<!-- Modifications to this file will be overwritten. -->
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>reports</title>
    <link rel="stylesheet" type="text/css" href="../../../css/themes/default/default.css">
    <script src="../../../../Ext-4/ext-all.js"></script>
    <link rel="stylesheet" href="../../../../Ext-4/resources/ext-theme-classic/ext-theme-classic-all.css">
    <script type="text/javascript" src="app.js"></script>
    <style type="text/css" media="screen">
        .task .x-grid-cell-inner {
            padding-left: 15px;
        }
        .x-grid-row-summary .x-grid-cell-inner {
            font-weight: bold;
        }
        .icon-grid {
            background: url(../../../icons/fam/grid.png) no-repeat 0 -1px;
        }
    </style>
</head>
<body>

<table width=100%  border="1" cellpadding="0" cellspacing="0">
    <tr class="titlebar"><td bgcolor="#99ccff" colspan="2">
            <font color="#330066">Outpatient Daily Mobidity Report</font></td></tr>
    <tr>
<!--        <td valign="top" width="18%" >--><?php //require_once '../acLinks.php'; ?><!--</td>-->
        <td valign="top"><div id="OpMobidity"></div></td>
    </tr>
</table>
</body>
</html>