<?php
$root_path='../../../';
$top_dir='modules/reports/';
# Root path used in templates
$TP_root_path='../../';
?>
