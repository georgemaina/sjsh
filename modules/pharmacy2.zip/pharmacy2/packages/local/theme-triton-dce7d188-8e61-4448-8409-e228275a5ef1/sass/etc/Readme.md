# theme-triton-dce7d188-8e61-4448-8409-e228275a5ef1/sass/etc

This folder contains miscellaneous SASS files. Unlike `"theme-triton-dce7d188-8e61-4448-8409-e228275a5ef1/sass/etc"`, these files
need to be used explicitly.
