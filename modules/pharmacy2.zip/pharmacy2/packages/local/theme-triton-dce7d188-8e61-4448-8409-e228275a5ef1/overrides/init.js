Ext.namespace('Ext.theme.is')['theme-triton-dce7d188-8e61-4448-8409-e228275a5ef1'] = true;
Ext.theme.name = 'theme-triton-dce7d188-8e61-4448-8409-e228275a5ef1';