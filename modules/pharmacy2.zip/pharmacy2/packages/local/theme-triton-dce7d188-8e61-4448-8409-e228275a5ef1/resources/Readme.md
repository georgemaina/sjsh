# theme-triton-dce7d188-8e61-4448-8409-e228275a5ef1/resources

This folder contains static resources (typically an `"images"` folder as well).
